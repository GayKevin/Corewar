/*
** asm_init_tab.h for asm_init_tab in /home/limone_m/rendu/CPE_2014_corewar/Include
** 
** Made by Maxime Limone
** Login   <limone_m@epitech.net>
** 
** Started on  Wed Apr  2 21:10:07 2014 Maxime Limone
** Last update Wed Apr  2 21:16:28 2014 Maxime Limone
*/

#ifndef ASM_INIT_TAB_H_
# define ASM_INIT_TAB_H_

char		**init_tab_inst_str(char **tab_inst_str);
char		*init_tab_inst_char(char *tab_inst_char);

#endif /*ASM_INIT_TAB_H_*/
