/*
** get_next_line.h for get_next_line in /home/limone_m/rendu/CPE_2014_corewar/Include
** 
** Made by Maxime Limone
** Login   <limone_m@epitech.net>
** 
** Started on  Wed Mar 19 20:42:03 2014 Maxime Limone
** Last update Fri Mar 28 12:30:16 2014 Kevin Gay
*/

#ifndef GET_NEXT_LINE_H_
# define GET_NEXT_LINE_H_
# define LEN 30000

char	*get_next_line(const int fd);
char	*clear_str(char *str, int nbr);
#endif /*GET_NEXT_LINE_H_*/
