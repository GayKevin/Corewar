/*
** put_infile_tool.h for put_infile_tool in /home/limone_m/rendu/CPE_2014_corewar
** 
** Made by Maxime Limone
** Login   <limone_m@epitech.net>
** 
** Started on  Wed Mar 26 18:56:09 2014 Maxime Limone
** Last update Thu Mar 27 18:14:01 2014 Kevin Gay
** Last update Thu Mar 27 17:29:57 2014 Maxime Limone
*/

#ifndef PUT_INFILE_TOOL_H_
# define PUT_INFILE_TOOL_H_

void		my_putchar_infile(char c, int fd);
void		my_putnbr_infile(int nb, int fd);
void		my_putstr_infile(char *str, int fd, int size);

#endif /*PUT_INFILE_TOOL_H_*/
